DDI Current Board / Phase2-2 R1 (2026-10-13)

KiCad8.x에서 DDI_Phase2_2_R1.kicad_pro를 열어 회로도 편집기로 진입합니다.
프로젝트 전체를 한 폴더에 압축 해제하고 라이브러리 하위 폴더를 유지합니다.
PDF 미리보기: DDI_Phase2_2_R1_Schematic.pdf
블록 다이어그램: Block_Diagrams.pdf(2장), Block_Diagram_Power/Control.svg 및 PNG
전체 부품표·연결 계약·수정 설명: DDI_Phase2_2_R1_Design_and_Blocks.html

반영된 변경
- R737 AVDDH1 / R757 VGH:20Ω→3.01Ω. 최대20mA에서60.2mV.
- R507 DIG / R527 VDDI:20Ω유지,1W2512 RT2512BKD7W20RL 후보로전력정격보강.
  Kembossed/7W1Wcode/0.1%/25ppm. 개별SKU발주확인필요. 새current limiter 추가아님.
  CTRL≤3.40V,Rmin19.93Ω,localambient≤85°C 조건에서0.580W<0.727W.
  열·동시단락·외부역급전조건의시험과최종승인이필요함.
- C1044.7µF50VX7R1210추가,C100100nF유지. 실제조건유효≥1µF인MPN선정필요.
- R1103VDDA직렬1Ω→0Ω.1µF+100nF유지.
- 최종BOM에서7개INA_CURRENT_LSB/ADC설정을자동생성. DDI_RESET/EN초기0유지.
- I2C2 MCU-side부하80pF로제약수정. LDO정착100ms는초기시험값으로보증값아님.

검증
- KiCad8.0.9 새export netlist와151개namednet의Ref.pin집합일치.
- 계약345개항목/899개핀. 회로도에는ERC전원플래그1개추가해346개심볼.
- KiCadERC 오류0/경고0/제외0. 모든NC19개고립확인.
- firmware7채널저항/환산/레지스터일치, C헤더문법·signed20해석독립재검토.
- 기존핀연결은동일, 추가연결은C104뿐. 부품값/패키지/정격/메타데이터는변경목록참고.
- schematic_additions.json #FLG1100은VDDAlink의ERC전원선언이며구매품아님.

중요한남은항목
- TVS/eFuse/buck서지최고전압은P0검증대기. TVS18V/29.2V clamp를그대로유지함.
- MOSCATO는논리placeholder. 실제pinmap/외장부품/powersequence/VGLoff/VGL1·2구조미확정.
- VGL현재한channel. 독립VGL1/VGL2출력을임의병렬연결하지않음.
- remoteFB의루프안정성/저부하전압정확도/시간축·ADCnoise/열/역급전실측미완료.
- 미확정footprint19개는pending_footprints.json.2512Kelvin은2physical/4logicalpads.
- GND_F=VGL_SRC이며시스템GND와합치지않음. USB_GND도별도.
- ERC통과는실측완료·제작승인이아님. audit_closure.json에닫힘조건및잔여항목기록.

생성·검증파일
revision_changes.json /audit_closure.json /root_final_review.json
firmware_definitions.json /Firmware_Definitions.h
source_contract.json /verified_netlist.xml /erc_report.json /verification_summary.json
독립검토에이전트3개결과파일은당시검토시점의코멘트도포함하므로root_final_review와closure를우선참고.
새2512단가는미확인이며기존1206단가를사용하지않음.

수정뒤재검증 (PATH에KiCadCLI가있는환경)
kicad-cli sch export netlist --format kicadxml -o verified_netlist.xml DDI_Phase2_2_R1.kicad_sch
kicad-cli sch erc --format json -o erc_report.json DDI_Phase2_2_R1.kicad_sch
python validate_project.py
kicad-cli sch export pdf -o DDI_Phase2_2_R1_Schematic.pdf DDI_Phase2_2_R1.kicad_sch
